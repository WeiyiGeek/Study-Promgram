<?php
/**#################################################
# Filename   :demo1.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月24日 星期三 19时24分00秒
# Description:
#######################################################**/

$str = "theende google baiiiiiidu alililibababa 
qihu360  this <b>is</b> a test  <b>Web</b> Serve"; 

$reg = "/Google/i";  //忽略大小写
$reg = "/^qihu/m";  //忽略换行得影响 
$reg = "/ba.+qi/s";  //默认匹配换号符号
$reg = "/gle bai/x";  //忽略空白匹配不到字符串
$reg = "/\<b\>(.*)\<\/b\>/isU";  //只匹配一次
$reg = "/\<b\>(.*?)\<\/b\>/";   //取消贪婪模式 .*? | .+?

if(preg_match_all($reg,$str,$arr)){
			echo "正则表达式 {$reg} 匹配 {$str} 成功！\n";
			print_r($arr);
		}else{
	        echo "没有找到匹配项！\n";
}


?>
