<?php
/**#################################################
# Filename   :demo8.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月26日 星期五 00时09分03秒
# Description:
#######################################################**/

$str = "This is a demo test!";

//strstr() 不区分大小写 
//stristr() 区分大小写
if(stristr($str,"test")){
	echo "Successful!   >>>>   ";
	echo stristr($str,"test",true)."\n"; //返回查找到字符串的前部分
}else{
	echo "Failed!\n";
}


//strpos  从前往后找
//strrpos  从后往前找

echo strpos($str,"is")."\t".strrpos($str,"is")."\n"; //返回从前往后与从后往前找的序号


//demo案例
//

function findUrl($url){
	$loc = strrpos($url,"/")+1;
	return substr($url,$loc)."\n";
}

echo findUrl("http://baidu.com/test.pdf");
echo findUrl("./.git/config.ini/demo.php");


?>
