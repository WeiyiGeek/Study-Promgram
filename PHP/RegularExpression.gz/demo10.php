<?php
/****
 *	
 *	preg_match_all()  与 preg_grep();
 *
 ****/

$str = <<<st
sssssshttps://www.csdn.net/qq_41611056/article/details/79360944?utm_source=blogxgwz1  sdsssdaaa
sdasdfsdfdfsdf   https://blg.csdn.com/ asdasdasdasd
adasdsadas https://bbs.cdn.net/ sadsadasdas
st;
//字符串多匹配
$reg = "/(https?|ftps?):\/\/(www|mail|bbs|ftp|blog|blg)\.(.*?)\.(net|com|org|cn)(?:[\w-\.\=\?\*\&\%]*)?/ims";

//默认函数就是采用flags为PREG_PATTREN_ORDER的标记
//preg_match_all($reg,$str,$arr,PREG_PATTERN_ORDER);

//PREG_SET_ORDER 
preg_match_all($reg,$str,$arr,PREG_SET_ORDER);
print_r($arr);

echo "\n";

//数组匹配
$arr = array("abcd1", "he llo2", "world", "ni hao");
$content=preg_grep('/\s/', $arr); //匹配一个空格字符
print_r($content);
