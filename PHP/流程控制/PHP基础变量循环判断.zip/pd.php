<!doctype HTML>
<html>
	<head lang="en">
	<meta charset="UTF-8">
<title>php判断语句</title>
</head>
<body>
<?php
  function getLevel($score){
  	//if判断语句
  	// if($score>=90){
  	// 	return '优秀';
  	// }elseif($score>=80){
  	// 	return '良好';
  	// }elseif($score>=70){
  	// 	return '一般';
  	// }elseif($score>=60){
  	// 	return '及格';
  	// }else{
  	// 	return '差';
  	// }

  	switch(intval($score/10)){  //intval将小数化成整数
  		case 10:
  		case 9:
  			return '优秀';
  			break;
  		case 8:
  			return '良好';
  			break;
  		case 7:
  			return '一般';
  			break;
  		case 6:
  			return '及格';
  			break;
  		default:
  			return '差';
  	}
  		return $result;
  }
  echo getLevel('86');
?>
</body>
</html>