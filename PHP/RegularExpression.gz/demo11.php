<?php
/**#################################################
# Filename   :demo11.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月28日 星期日 23时01分53秒
# Description:
#######################################################**/



//字符串分割函数：只能按照指定字符串进行分割，然后返回到数组中
//     explode();  implode() == jion();
//
//正则表达式分割函数:按照我们定义得自定义表达式进行分割；
//		preg_split();


$str = "This is a de,mo space@work！";
print_r(explode(" ",$str,5));  //字符分割 ,如果未定义分割字符即""，该函数会报错,还可以设置分割次数；

print_r(preg_split("/[\s\,\@]/",$str));  //按照空格和@和,进行分割

print_r(preg_split("/[\s\,\@]/",$str,-1,PREG_SPLIT_NO_EMPTY|PREG_SPLIT_OFFSET_CAPTURE));  //按照空格和@和,进行分割,设置偏移量(处于字符串得位置)

/** 区分 flag 标记是任何下面得组合以位或运算 **/
print_r(preg_split('||',"lamp",-1)); //带有空格
print_r(preg_split('||',"lamp",-1,PREG_SPLIT_NO_EMPTY)); //带有非空标记

//字符分割后进行组合
$arr = preg_split('||',"lamp",-1,PREG_SPLIT_NO_EMPTY); //带有非空标记lamp
echo implode("-|-",$arr)."\n";  //组合分割得字符
echo join("-|-",$arr)."\n";  //组合分割得字符

list($a,$b) = explode("_","WEIYI_GEEK");
echo "{$a}++++{$b}";

?>
