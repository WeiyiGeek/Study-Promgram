
<?php
/**#################################################
# Filename   :demo13.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月30日 星期二 13时23分26秒
# Description:
#######################################################**/
//
// preg_replace() 高阶用法
//

$str = "谁说的http://www.aliyun.com/jiaocheng/17711.html殊的<b>替换</b>需求（<u>比如正则表达式</u>），你应该使用该函数替换 <font color='red'>ereg_replace()</font> 和";

$reg = array(
	"/\<[\/\!]*?[^\<\>]*?\>/i",
	'/(https?|ftps?):\/\/(www|mail|bbs|ftp)\.(.*?)\.(net|com|org|cn)/',
	'/\d/');

//注意：上面正则加上e不支持/e参数 ，直接使用preg_replace_callback();
$req = array(
			'#',
			'<a href="$1://$2.$3.$4"></a>',			
			'@'
		);
$newstr = preg_replace($reg,$req,$str);
echo $newstr."\n\n";

//preg_replace_callback();
//可以在回调函数中写入php支持的函数
$text = "今天是2014-02-14，明年是2018-2-25和您在一起?\n";
$reg = "/(\d{4})-(\d{2})-(\d{2})/";
$str = preg_replace_callback($reg,function ($value){return strtoupper("year:").($value[1]+1).$value[2];},$text);
echo $str;


$ref = "|(\d{4}-)|";
//这种方式能全匹配
function call($v){
	return ($v[1]+4)."-";
}
//掉用call函数
echo preg_replace_callback($ref,"call",$str);



?>
