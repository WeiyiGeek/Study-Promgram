<?php

echo "<pre>";
/**#################################################
# Filename   :demo9.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月26日 星期五 10时49分02秒
# Description:
#######################################################**/
header("Content-type:text/html;charset=utf-8");

//preg_match()函数案例;
$str = "This is a ve10rivty reguler";
//采用strstr
if(strstr($str,"10")){
	echo "成功匹配\n<br>";
}else{
	echo "匹配失败\n";
}
//主角
$reg = "/\d+/";
if(preg_match($reg,$str,$arr)){
	echo "成功匹配\n<br>";
	print_r($arr);
}else{
	echo "匹配失败\n";
}

if(isset($_POST['dosubmit'])){
	//表示$以什么来结束 ->	\Z
	if(!preg_match('/^\S+$/',$_POST['username'])){
		echo "用户名不能有空！</br>";
		die("Error");	
	}
	if(!preg_match('/\w+([+-.]*)?\@\w+\.\w+/',$_POST['email'])){
		echo "邮箱格式错误 </br>";
		die("Error");
	}
	if(!preg_match('/(https?)\:\/\/(bbs|ftps|www)?(.*?)\.(com|cn|net)/',$_POST['url'],$arr)){
		echo "url格式有错</br>";
		die("Error");
	}else{
		echo "完整的URL:{$arr[0]}<br>";
		echo "协议:{$arr[1]}<br>";
		echo "主机:{$arr[2]}<br>";
		echo "域名:{$arr[3]}<br>";
		echo "顶级域名:{$arr[4]}<br>";
	}


	echo "提交成功";
}

echo "</pre>";
?>

<form action="" method="post">
	<label> Username: </label><input type="text" name="username" value=""/><br>
	<label> Emaill: </label><input type="email" name="email" value=""/><br>
	<label> URL: </label><input type="text" name="url" value=""/><br>
	<input type="submit" name="dosubmit" value="submit">
</form>
