<?php
/**#################################################
# Filename   :demo.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月24日 星期三 18时49分50秒
# Description:
#######################################################**/
	$str = "I love you? very day, I want to chong qing";
	$reg = "/\w/"; //有时需要注意 ' 与 " 不同 

	echo $str."\n";
	echo preg_replace($reg,"#",$str)."\n"; //将所有得单词替换成为#
	
	print_r(preg_split($reg,$str)); //将匹配到到得字符串转换为空,放在数组里面

	echo "\n\n";
	if(preg_match($reg,$str,$arr)){
	
		echo "正则表达式匹配成功！\n";
	}else{
	
		echo "没有找到匹配项！\n";
	}
?>
