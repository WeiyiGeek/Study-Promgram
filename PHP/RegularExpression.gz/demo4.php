<?php
/**#################################################
# Filename   :demo1.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月24日 星期三 19时24分00秒
# Description:
#######################################################**/

$str = "oraclesql db redis pregresssql"; 
$str1 = "web internet2014-10-27http://www.baidu.comtest2018/10/25 web"; 

$reg = "/orac(le|my)sql/"; //改变优先级级别
$reg1 = "/(mysql)*/";  //括号里面整体将变成匹配得对象
$reg2 = "/(http|ftp|https)\:\/\/(www|mail|ftp)\.(.*)?\.(net|cn|com)/";       //每个小括号都是独立得将输出到数组中
$reg3 = "/(\d{4}(-)\d{2}(-)\d{2}|\d{4}(\/)\d{2}(\/)\d{2})/";
$reg4 = '/\d{4}(-|\/)\d{2}\1\d{2}/';  //这里的\1其实就是代表了第一个子模式(-\/)
$reg5 = '/(?:\d{4})(-|\/)\d{2}\1\d{2}/';  //这里的?:表示将第一个括号变成子模式 - 这时\1其实就是代表了第二()里面的原子
if(preg_match_all($reg3,$str1,$arr)){
			echo "正则表达式 {$reg3} 匹配 {$str1} 成功！\n";
			print_r($arr);
		}else{
	        echo "没有找到匹配项！\n";
 }


?>
