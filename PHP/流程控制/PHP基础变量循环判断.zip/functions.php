 function PHP函数<br/>
 <?php
    function traceHelloPHP(){
    	echo 'HELLO CQSDZY.COM<br>';
    	echo 'HELLO eita!!<br/>';
    }

    echo "// traceHelloPHP()<br>
 		  //调用执行Run<br>";
    $func = 'traceHelloPHP';
    $func();

    echo '<br>//传递参数时<br>';
    function sayHello($name){
    	echo "hello".$name.'<BR>';
    }
    sayHello('Weione');
    sayHello('EIAT');

    echo "<br>//If 传入很多参数时<br>";

   	function traceNum($a,$b){
   		// echo 'a = '.$a.', b = '.$b.'<br>';
   		echo " a = $a , b = $b<br>";
   	}
	traceNum(78,99);
	//PHP内置函数也可以相加相减
	function add($a,$b){
		return $a+$b;
	}
	echo add(10,2).'<br>';
?>
