// JavaScript Document
/**
***CSS Document
***Author:Eita(教育信息技术协会)
**/
function imgDisplay(){
    var Div = document.getElementById('picList').getElementsByTagName('div');
	var divHeight = 160;
	for(var i =0 ;i<Div.length;i++){
		Div[i].onmouseover = showMeg;
		Div[i].onmouseout = hideMeg;
		}
	function showMeg(){
		this.getElementsByTagName('a')[0].style.top = 0;
		}
	function hideMeg(){
		this.getElementsByTagName('a')[0].style.top = divHeight+'px';
		}
	}
	imgDisplay();