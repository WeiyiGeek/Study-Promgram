<?php
/**#################################################
# Filename   :demo6.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月25日 星期四 22时52分14秒
# Description:
#######################################################**/

$str = <<<st
	邮箱信息:asd+sad@qq.com大苏打啊test.test@cque.edu.cn阿斯顿阿156-46564@163.com斯顿啊阿斯顿
st;


$reg = "/\w+@\w+\.\w+/i"; //邮箱最小正则匹配
$reg = "/\w+([+-.]\w+)*@\w+\.\w+/i"; //邮箱不规则匹配
$reg = "/\w+([+-.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/i"; //邮箱不规则匹配1


if(preg_match_all($reg,$str,$arr)){
	echo "正则表达式 {$reg} 匹配 $str 成功！\n";
	print_r($arr);
}else{
	echo "匹配失败|！\n";
}


?>
