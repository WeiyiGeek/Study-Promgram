<?php
/**#################################################
# Filename   :demo1.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月24日 星期三 19时24分00秒
# Description:
#######################################################**/

$str = "this is a regexpress rule! 12.01	
sadsad
"; 
	$reg = "/[a-z]{4}/";
        if(preg_match($reg,$str,$arr)){
			echo "正则表达式 {$reg} 匹配 {$str} 成功！\n";
			print_r($arr);
		}else{
	        echo "没有找到匹配项！\n";
 }


?>
