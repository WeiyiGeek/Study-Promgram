
<?php
//在这个例子中，preg_quote($word) 用于保持星号原文涵义，使其不使用正则表达式中的特殊语义。

$text = "This book is *very* difficult to find.";
echo  "原字符串:".$text."\n";

//注意下面这种不对*加转义会报错
$word = "/\*very\*/";
$textbody = preg_replace ($word,"<i>".$word."</i>",$text);
echo $textbody."\n对比VS\n";

$reg = "*very*";
$str = preg_replace("/".preg_quote($reg)."/","<b>".$reg."</b>",$text);
echo $str."\n\n";

//字符串排顺序
$s="Hello";
$t="hello";
echo strcmp($s,$t)."\n";  //区分大小写，如果使用该方法必须将字符串同时转换成为 大写strtoupper() 或者小写strtolower（）
echo strncmp($s,$t,5)."\n";   
echo strcasecmp($s,$t),"\n";


$arr = ["file","File","fiLe1","fIle"];
echo usort($arr,"strcmp")."\n\n"; //利用系统排序函数也可以，当然也可以自己写匿名函数;
print_r($arr);
?>

