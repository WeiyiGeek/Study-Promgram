<!DOCTYPE Html>
<html>
<head lang="en">
<meta charset="UTF-8">
	<title>PHP基础语法</title>
</head>
<body>
PHP基础教程
<br/>
<?php echo "I love PHP!";?>
</body>
</html>