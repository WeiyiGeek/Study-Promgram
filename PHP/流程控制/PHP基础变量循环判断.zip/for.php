<?php 
for($i=0;$i<100;$i++){
	echo 'Hello'.$i.'<br/>';
	if ($i==20) {
		continue;  //结束当前值的循环
	}
	echo "----Run----".$i.'<br>';
}

// for($i=0;$i<100;$i++){
// 	echo 'Hello'.$i.'<br/>';
// 	if ($i==20) {
// 		break;  //结束全部for循环不在执行
// 	}
// }

// $i=0;
// while($i<10){
// 	echo 'Hello'.$i.'<br>';
// 	$i++;
// }
	
// $i=0;
// do{
// 	echo 'Hello'.$i.'<br>';
// 	$i++;
// }while($i<100);