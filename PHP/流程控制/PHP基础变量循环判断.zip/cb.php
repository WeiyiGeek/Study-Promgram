//PHP变量 与 PHP常量
<br/>
<?php   //PHP变量 
$a=10;
$b=30;
$c=30;
echo ($a+$b)*$c;
echo '<br/>';
//php常量
const THE_VALUE = 99;
ECHO THE_VALUE;
//另外一直赋值常量-中途不能修改
define ('THE_VALUE1',999999);
echo '<br>';
echo THE_VALUE1;
echo THE_VALUE1;