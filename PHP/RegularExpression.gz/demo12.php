<?php
/**#################################################
# Filename   :demo12.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月28日 星期日 23时38分09秒
# Description:
#######################################################**/
/**
 *	字符串替换函数 str_replace
 *	正则替换函数  preg_replace
 **/


//字符串替换
$num = 0;
$str="这时不可显示的文字，百度站点：http://baidu.com/test/test.php，帅哥美女，夏天图片";
$newstr = str_replace("test","geek",$str,$num);   //替换函数，最后一个参数是替换得次数
$newstr = str_replace(array("不可","美女","图片"),"**",$str,$num);
$newstr1 = str_replace(array("百度","baidu","美女"),array("腾讯","QQ","靓女"),$str,$num); //如果被替换的字符串小于替换的字符串的数量匹配则为空；
echo "Str ：{$str} \n";
echo "Restr：".$newstr1;
echo "\n替换得次数为:{$num}\n\n\n";


//正则替换
$str ="如果没有一些特殊的<b>替换</b>需求（<u>比如正则表达式</u>），你应该使用该函数替换 <font color='red'>ereg_replace()</font> 和 preg_replace()。 ";
$reg = "/\<[\/\!]*?[^\<\>]*?\>/is"; //取消字符串中的标记
$pregstr = preg_replace($reg,"",$str); 
$pregstr = preg_replace($reg,"",$str,4); //替换四次
echo $str."\n";
echo $pregstr."\n\n\n";

//preg_replace(); 函数关键用法利用子模式进行提取字符串
$str1 = "百度站点:https://www.baidu.com 腾讯站点：http://www.qq.com 我想替换成A标签";
$reg = '/(https?|ftps?):\/\/(www|mail|bbs|ftp)\.(.*?)\.(net|com|org|cn)/'; 
$nstr = preg_replace($reg,'<a href="$1://$2.$3.$4">连接</a>',$str1);
echo $nstr."\n\n";


//
//
//
?>
