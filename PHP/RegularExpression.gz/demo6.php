<?php
/**#################################################
# Filename   :demo6.php
# Author     :WeiyiGeek
# CreatedTime:2018年10月25日 星期四 22时52分14秒
# Description:
#######################################################**/

$str = <<<st
	s啊撒大声地 http://weibo.com/?c=spr_web_sq_firefox_weibo_t001
	http://zone.butian.360.net/ 社区
	百度：http://baidu.com/`
	百度：https://www.baidu.cn/php
	百度：http://bbs.baidu.com/php/test.php
st;
$reg = "/(https?)\:\/\/(www|bbs|zone)?(.*?)\.(com|net|cn)\/(\w.*|\?.*)?/im";

if(preg_match_all($reg,$str,$arr)){
	echo "正则表达式 {$reg} 匹配 $str 成功！\n";
	print_r($arr);
}else{
	echo "匹配失败|！\n";
}


?>
