<?php
	function traceNum(){

	for ($i=0; $i<10; $i++) { 
		if(!($i%2==0)){ //&& 且满足两者
			echo $i.'<br>';
		}

		// 	if ($i%2==1 || $i%3==0) {  //||或 满足一个即可
		// 		echo $i.'<br>';
		// 	}

		// if ($i%2==1 && $i%3==0) { //&& 且满足两者
		// 	echo $i.'<br>';
		// }
		}
	}
traceNum();